#!/usr/bin/python3

from waitress import serve
from paste.translogger import TransLogger
import app

serve(TransLogger(app.app, setup_console_handler=False), host='0.0.0.0', port=1337)
