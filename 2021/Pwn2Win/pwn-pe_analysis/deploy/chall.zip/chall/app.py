#!/usr/bin/python3

from flask import Flask, render_template, request
from os import getcwd, path, remove
from random import choice
from string import ascii_letters
from subprocess import run, PIPE

CWD = getcwd()
UP_DIR = path.join(CWD, 'up')
LETTERS = ascii_letters

app = Flask(__name__)

# Configuration
app.config['MAX_CONTENT_LENGTH'] = 6000

def gen_rand_name():
    return ''.join(choice(LETTERS) for _ in range(18))

def analyze(filename):
    output = run(['readpe', filename], stdout=PIPE).stdout.decode()
    if len(output) == 0:
        return 'Something went wrong! Are you sending a PE file?'
    return output

@app.route('/', methods=['GET', 'POST'])
def page():
    if request.method == "POST":
        filename = path.join(UP_DIR, gen_rand_name())
        f = request.files['file']
        f.save(filename)

        output = analyze(filename)

        remove(filename)
        return render_template('cmd_output.html', output=output)
    
    return render_template('upload.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=1337)
