# Instructions

In order to reproduce the challenge environment locally:

1. Use the Windows Server 2008 whose version is shared in `systeminfo.jpg`.
2. Install `python3` and the required packages using `pip` and `requirements.txt`.
3. Execute `python waitress_server.py`.

PS: The server dlls are shared in `server_dlls` folder.
